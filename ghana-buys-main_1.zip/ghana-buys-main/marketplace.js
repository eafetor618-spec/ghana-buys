/* Ghana Buys — shared marketplace helpers, loaded by every page.
   TODO: replace these two placeholders with your actual Supabase project
   values (Project Settings → API → Project URL / anon public key). */
const SUPABASE_URL = 'https://wstjabsjsxwbkbiouyug.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndzdGphYnNqc3h3YmtiaW91eXVnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODcwMDA1NzksImV4cCI6MjEwMjU3NjU3OX0.EMJztYqk969nlAxW6bygMKB0FfHG6rRdBhvOjJ-qEWk';

const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

/* Paystack — public/test key only, safe to expose client-side.
   Get this from Paystack dashboard -> Settings -> API Keys (pk_test_... or pk_live_...) */
const PAYSTACK_PUBLIC_KEY = 'pk_test_0966980bbd23d49dc4e263d5640edd2c98c6396d';

// Generic caller for our Paystack-backed edge functions (feature-listing,
// store-subscription, etc). Each holds the Paystack SECRET key server-side
// and does the real verification — never trust a client-side "success" signal alone.
async function callPaidFeatureFn(fnName, action, payload) {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) throw new Error('Not logged in');
  const res = await fetch(SUPABASE_URL + '/functions/v1/' + fnName, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + session.access_token
    },
    body: JSON.stringify(Object.assign({ action: action }, payload))
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// Opens the Paystack popup, then verifies with the server before resolving.
// Requires https://js.paystack.co/v1/inline.js loaded on the page.
function startPaidFeatureCheckout(fnName, payload, onSuccess, onError) {
  callPaidFeatureFn(fnName, 'initialize', payload)
    .then(function (init) {
      const handler = PaystackPop.setup({
        key: PAYSTACK_PUBLIC_KEY,
        email: init.email,
        amount: init.amount,
        currency: 'GHS',
        ref: init.reference,
        callback: function () {
          callPaidFeatureFn(fnName, 'verify', { reference: init.reference })
            .then(function (result) { onSuccess(result); })
            .catch(function (err) { onError(err); });
        },
        onClose: function () {}
      });
      handler.openIframe();
    })
    .catch(function (err) { onError(err); });
}

function startFeatureListingCheckout(listingId, onSuccess, onError) {
  startPaidFeatureCheckout('feature-listing', { listing_id: listingId }, onSuccess, onError);
}

function startStoreSubscriptionCheckout(onSuccess, onError) {
  startPaidFeatureCheckout('store-subscription', {}, onSuccess, onError);
}

function startAiDescriptionCheckout(onSuccess, onError) {
  startPaidFeatureCheckout('pay-ai-description', {}, onSuccess, onError);
}

// Buyer-pays-seller checkout, routed via Paystack subaccount split so the
// money settles directly with the seller — Ghana Buys never holds it.
async function callPayListingFn(action, payload) {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) throw new Error('Not logged in');
  const res = await fetch(SUPABASE_URL + '/functions/v1/pay-listing', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + session.access_token
    },
    body: JSON.stringify(Object.assign({ action: action }, payload))
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function startListingPaymentCheckout(listingId, onSuccess, onError) {
  callPayListingFn('initialize', { listing_id: listingId })
    .then(function (init) {
      const handler = PaystackPop.setup({
        key: PAYSTACK_PUBLIC_KEY,
        email: init.email,
        amount: init.amount,
        currency: 'GHS',
        ref: init.reference,
        subaccount: init.subaccount,
        callback: function () {
          callPayListingFn('verify', { reference: init.reference })
            .then(function (result) { onSuccess(result); })
            .catch(function (err) { onError(err); });
        },
        onClose: function () {}
      });
      handler.openIframe();
    })
    .catch(function (err) { onError(err); });
}

// In-app messaging: insert one message row. listingId may be null for a
// conversation not tied to a specific listing. Throws if not logged in,
// the message is empty, or the insert is rejected (e.g. messaging yourself).
async function sendMessage(recipientId, listingId, content) {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) throw new Error('Not logged in');
  const trimmed = String(content || '').trim();
  if (!trimmed) throw new Error('Write a message first.');
  if (recipientId === session.user.id) throw new Error("You can't message yourself.");
  const senderName = (session.user.user_metadata && session.user.user_metadata.display_name) || session.user.email;
  const { error } = await sb.from('messages').insert({
    sender_id: session.user.id,
    recipient_id: recipientId,
    listing_id: listingId || null,
    sender_name: senderName,
    content: trimmed
  });
  if (error) throw error;
}

// Reviews: insert a rating (1-5) + optional comment for a completed, paid
// order. A DB trigger validates listingOrderId actually belongs to
// buyerId and is paid, and auto-fills seller_id/listing_id from it.
async function submitReview(listingOrderId, buyerId, rating, comment) {
  const ratingNum = Number(rating);
  if (!ratingNum || ratingNum < 1 || ratingNum > 5) throw new Error('Please choose a star rating.');
  const { error } = await sb.from('reviews').insert({
    listing_order_id: listingOrderId,
    buyer_id: buyerId,
    rating: ratingNum,
    comment: (comment || '').trim() || null
  });
  if (error) throw error;
}

const GHANA_REGIONS = [
  'Greater Accra', 'Ashanti', 'Western', 'Western North', 'Central',
  'Eastern', 'Volta', 'Oti', 'Northern', 'Savannah', 'North East',
  'Upper East', 'Upper West', 'Bono', 'Bono East', 'Ahafo'
];

const CATEGORIES = [
  'Phones & Electronics',
  'Fashion',
  'Home & Living',
  'Vehicles',
  'Property',
  'Services',
  'Data & Connectivity',
  'Other'
];

function escapeHtml(str) {
  return String(str == null ? '' : str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatPrice(price) {
  if (price === null || price === undefined || price === '') return 'Price on request';
  const n = Number(price);
  if (Number.isNaN(n)) return 'Price on request';
  return '₵' + n.toLocaleString('en-GH');
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const diffMs = Date.now() - d.getTime();
  const diffDays = Math.floor(diffMs / 86400000);
  if (diffDays <= 0) return 'today';
  if (diffDays === 1) return 'yesterday';
  if (diffDays < 7) return diffDays + ' days ago';
  if (diffDays < 30) return Math.floor(diffDays / 7) + (Math.floor(diffDays / 7) === 1 ? ' week ago' : ' weeks ago');
  return d.toLocaleDateString('en-GH', { day: 'numeric', month: 'short', year: 'numeric' });
}

// Normalizes Ghanaian numbers (e.g. "024 123 4567" or "+233 24 123 4567") to
// wa.me's expected format and builds a click-to-chat link with a prefilled message.
function whatsappLink(phone, message) {
  let digits = String(phone || '').replace(/\D/g, '');
  if (digits.startsWith('0')) digits = '233' + digits.slice(1);
  else if (!digits.startsWith('233')) digits = '233' + digits;
  return 'https://wa.me/' + digits + '?text=' + encodeURIComponent(message || '');
}

// Self-contained inline SVG — does NOT rely on the <symbol> sprite that only
// index.html and the guide pages define, so it renders correctly on every
// page (including marketplace/listing/post/account, which don't have it).
function placeholderIconSVG() {
  return '<svg class="icon" viewBox="0 0 24 24" width="36" height="36" fill="none" ' +
    'stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' +
    '<rect x="3.5" y="7" width="17" height="13" rx="2"></rect>' +
    '<path d="M8 7V5.5A2.5 2.5 0 0 1 10.5 3h3A2.5 2.5 0 0 1 16 5.5V7"></path>' +
    '</svg>';
}

function listingCardHTML(l) {
  const galleryUrls = (l.image_urls && l.image_urls.length) ? l.image_urls : (l.image_url ? [l.image_url] : []);
  const img = galleryUrls.length
    ? (galleryUrls.length > 1
        ? '<div class="listing-thumb-scroll">' +
            galleryUrls.map(function (url, i) {
              return '<div class="listing-thumb-slide"><img src="' + escapeHtml(url) + '" alt="' + escapeHtml(l.title) + ' — photo ' + (i + 1) + '"></div>';
            }).join('') +
          '</div>' +
          '<div class="listing-thumb-dots">' +
            galleryUrls.map(function (_, i) {
              return '<span class="listing-thumb-dot' + (i === 0 ? ' active' : '') + '"></span>';
            }).join('') +
          '</div>'
        : '<img src="' + escapeHtml(galleryUrls[0]) + '" alt="' + escapeHtml(l.title) + '">')
    : placeholderIconSVG();
  const soldBadge = l.status === 'sold' ? '<span class="listing-sold-badge">Sold</span>' : '';
  const isFeatured = l.featured && l.featured_until && new Date(l.featured_until) > new Date();
  const featuredBadge = isFeatured ? '<span class="listing-featured-badge">★ Featured</span>' : '';
  const videoBadge = l.video_url ? '<span class="listing-video-badge">▶ Video</span>' : '';

  return (
    '<a class="listing-card" href="/listing?id=' + l.id + '">' +
      '<div class="listing-thumb-wrap">' +
        '<div class="listing-thumb">' + img + '</div>' +
        soldBadge + featuredBadge + videoBadge +
        '<button type="button" class="save-btn" data-id="' + l.id + '" aria-label="Add to cart">' +
          '<svg viewBox="0 0 24 24" width="18" height="18"><circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/><path d="M2.5 3h2.4l1.1 3M5.9 6l1.9 8.6a1.6 1.6 0 0 0 1.6 1.3h7.6a1.6 1.6 0 0 0 1.6-1.3L20.5 6H5.9z"/></svg>' +
        '</button>' +
      '</div>' +
      '<div class="listing-body">' +
        '<span class="listing-price">' + formatPrice(l.price) + (l.negotiable ? ' <span class="negotiable-tag">Negotiable</span>' : '') + '</span>' +
        '<h3>' + escapeHtml(l.title) + '</h3>' +
        '<div class="listing-meta">' +
          '<span>' + escapeHtml(l.category === 'Other' && l.custom_category ? l.custom_category : l.category) + '</span>' +
          (l.location ? '<span>📍 ' + escapeHtml(l.location) + '</span>' : '') +
        '</div>' +
      '</div>' +
    '</a>'
  );
}

// Keeps each card's dot indicator in sync with its own swipe position, and
// stops the card link from navigating when the drag itself was a swipe
// rather than a tap (mirrors the save-btn's own stopPropagation pattern).
function bindListingCardGalleries(container) {
  const root = container || document;
  root.querySelectorAll('.listing-thumb-scroll').forEach(function (scrollEl) {
    if (scrollEl.dataset.galleryBound) return;
    scrollEl.dataset.galleryBound = '1';

    const card = scrollEl.closest('.listing-card');
    const dots = card ? card.querySelectorAll('.listing-thumb-dot') : [];
    let startX = null;
    let dragged = false;

    scrollEl.addEventListener('touchstart', function (e) {
      startX = e.touches[0].clientX;
      dragged = false;
    }, { passive: true });
    scrollEl.addEventListener('touchmove', function (e) {
      if (startX !== null && Math.abs(e.touches[0].clientX - startX) > 8) dragged = true;
    }, { passive: true });

    scrollEl.addEventListener('click', function (e) {
      if (dragged) { e.preventDefault(); e.stopPropagation(); }
    });

    let scrollTimeout;
    scrollEl.addEventListener('scroll', function () {
      clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(function () {
        const index = Math.round(scrollEl.scrollLeft / scrollEl.clientWidth);
        dots.forEach(function (dot, i) { dot.classList.toggle('active', i === index); });
      }, 80);
    });
  });
}

// Marks every .save-btn currently in the DOM whose listing is already saved
// by the signed-in viewer. Safe to call repeatedly (e.g. after each render);
// no-ops quietly if the viewer isn't logged in.
async function refreshSavedButtons() {
  bindListingCardGalleries();
  const buttons = document.querySelectorAll('.save-btn');
  if (!buttons.length) return;
  const { data: { session } } = await sb.auth.getSession();
  if (!session) return;

  const { data, error } = await sb.from('saved_listings').select('listing_id').eq('user_id', session.user.id);
  if (error || !data) return;
  const savedIds = new Set(data.map(function (r) { return r.listing_id; }));
  buttons.forEach(function (btn) {
    btn.classList.toggle('saved', savedIds.has(btn.dataset.id));
  });
}

async function toggleSaveListing(id, btn) {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) {
    window.location.href = '/account?next=' + encodeURIComponent(location.pathname + location.search);
    return;
  }

  const alreadySaved = btn.classList.contains('saved');
  btn.disabled = true;
  if (alreadySaved) {
    await sb.from('saved_listings').delete().eq('user_id', session.user.id).eq('listing_id', id);
    btn.classList.remove('saved');
  } else {
    await sb.from('saved_listings').insert({ user_id: session.user.id, listing_id: id });
    btn.classList.add('saved');
  }
  btn.disabled = false;
}

// Delegated so it works for cards rendered anywhere, at any time.
document.addEventListener('click', function (e) {
  const btn = e.target.closest('.save-btn');
  if (!btn) return;
  e.preventDefault();
  e.stopPropagation();
  toggleSaveListing(btn.dataset.id, btn);
});

// Keeps the "Log in" / "My Account" nav link in sync with auth state on every page,
// and shows a badge with the count of unread messages (across all listings/orders).
(async function initNavAccountLink() {
  const link = document.getElementById('navAccountLink');
  if (!link) return;

  // Use a dedicated label span so updating the text never wipes out the badge
  // (link.textContent = '...' would destroy any appended child elements).
  const label = document.createElement('span');
  label.textContent = link.textContent;
  link.textContent = '';
  link.appendChild(label);

  const badge = document.createElement('span');
  badge.className = 'nav-unread-badge';
  badge.style.cssText = 'display:none; margin-left:6px; background:var(--red); color:#fff; ' +
    'font-family:\'IBM Plex Mono\',monospace; font-size:0.7rem; font-weight:700; line-height:1; ' +
    'padding:3px 6px; border-radius:10px;';
  link.appendChild(badge);

  async function refreshUnreadBadge(userId) {
    if (!userId) {
      badge.style.display = 'none';
      link.setAttribute('href', '/account');
      return;
    }
    const { count, error } = await sb
      .from('messages')
      .select('id', { count: 'exact', head: true })
      .eq('recipient_id', userId)
      .eq('read', false);
    if (error || !count) {
      badge.style.display = 'none';
      link.setAttribute('href', '/account');
      return;
    }
    badge.textContent = count > 99 ? '99+' : String(count);
    badge.style.display = '';
    link.setAttribute('href', '/account?tab=messages');
  }

  function applySession(session) {
    if (session && session.user) {
      label.textContent = 'My Account';
      refreshUnreadBadge(session.user.id);
    } else {
      label.textContent = 'Log in';
      refreshUnreadBadge(null);
    }
  }

  try {
    const { data: { session } } = await sb.auth.getSession();
    applySession(session);
  } catch (err) {
    // leave default "Log in" if the session check fails
  }

  sb.auth.onAuthStateChange(function (_event, session) {
    applySession(session);
  });

  // Live-refresh the badge when a new message arrives while the page is open,
  // without needing a reload.
  sb
    .channel('nav-unread-messages')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, async function () {
      const { data: { session } } = await sb.auth.getSession();
      if (session && session.user) refreshUnreadBadge(session.user.id);
    })
    .subscribe();
})();

// Register the PWA service worker (static-asset caching + offline fallback).
// Registered immediately (not deferred to window 'load') so PWA analysis
// tools that don't wait for the full load event still detect it, and errors
// are logged instead of silently swallowed so registration failures are
// actually visible in the console.
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/service-worker.js').catch(function (err) {
    console.error('Service worker registration failed:', err);
  });
}

// Push notifications: for new message replies and saved-search matches.
// Subscribing requires the browser's Notification permission, which must be
// requested from a real user action (a button click), not on page load.
const VAPID_PUBLIC_KEY = 'BJj0cU40UT7Z1-TPDRtDqIQG2_4pXUVpOAnzAl7aVYQIaQm_Iw93C-aPSDZWWhUSM9YxesFZ9BRMdXjwyahkRpw';

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; i++) outputArray[i] = rawData.charCodeAt(i);
  return outputArray;
}

function pushNotificationsSupported() {
  return 'serviceWorker' in navigator && 'PushManager' in window;
}

// Returns 'granted', 'denied', 'default' (not yet asked), or 'unsupported'.
function pushNotificationPermissionState() {
  if (!pushNotificationsSupported()) return 'unsupported';
  return Notification.permission;
}

async function enablePushNotifications(userId) {
  if (!pushNotificationsSupported()) throw new Error('Notifications aren\u2019t supported on this browser.');

  const permission = await Notification.requestPermission();
  if (permission !== 'granted') throw new Error('Notifications permission was not granted.');

  const registration = await navigator.serviceWorker.ready;
  let subscription = await registration.pushManager.getSubscription();
  if (!subscription) {
    subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
    });
  }

  const json = subscription.toJSON();
  const { error } = await sb.from('push_subscriptions').upsert({
    user_id: userId,
    endpoint: json.endpoint,
    p256dh: json.keys.p256dh,
    auth_key: json.keys.auth
  }, { onConflict: 'endpoint' });

  if (error) throw error;
  return true;
}

async function disablePushNotifications() {
  if (!pushNotificationsSupported()) return;
  const registration = await navigator.serviceWorker.ready;
  const subscription = await registration.pushManager.getSubscription();
  if (subscription) {
    await sb.from('push_subscriptions').delete().eq('endpoint', subscription.endpoint);
    await subscription.unsubscribe();
  }
}

// Install prompt: Android/Chrome supports a real triggerable install popup
// (beforeinstallprompt). iOS Safari has no such API at all — Apple never
// exposes one — so the only option there is to show instructions for the
// manual Share > Add to Home Screen steps.
(function () {
  const DISMISS_KEY = 'gb_install_dismissed';

  function isStandalone() {
    return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  }
  function isIos() {
    return /iphone|ipad|ipod/.test(window.navigator.userAgent.toLowerCase());
  }

  if (isStandalone() || localStorage.getItem(DISMISS_KEY)) return;

  let deferredPrompt = null;
  let banner = null;

  function buildBanner(mode) {
    const el = document.createElement('div');
    el.className = 'install-banner';
    el.innerHTML =
      '<img src="/icon-192.png" alt="" class="install-banner-icon">' +
      '<div class="install-banner-text">' +
        '<strong>Install Ghana Buys</strong>' +
        '<span>' + (mode === 'ios' ? 'Get it on your Home Screen — faster, full-screen.' : 'Add the app for faster, full-screen browsing.') + '</span>' +
      '</div>' +
      '<button type="button" class="install-banner-btn" id="installBannerBtn">' + (mode === 'ios' ? 'How' : 'Install') + '</button>' +
      '<button type="button" class="install-banner-close" id="installBannerClose" aria-label="Dismiss">×</button>';
    document.body.appendChild(el);
    return el;
  }

  function showIosSheet() {
    const sheet = document.createElement('div');
    sheet.className = 'install-ios-sheet';
    sheet.innerHTML =
      '<div class="install-ios-sheet-inner">' +
        '<h3>Install Ghana Buys</h3>' +
        '<ol>' +
          '<li>Tap the <strong>Share</strong> button <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12M8 7l4-4 4 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"/></svg> in Safari\'s toolbar</li>' +
          '<li>Scroll down and tap <strong>Add to Home Screen</strong></li>' +
          '<li>Tap <strong>Add</strong> in the top right</li>' +
        '</ol>' +
        '<button type="button" class="btn-primary" id="installIosCloseBtn">Got it</button>' +
      '</div>';
    document.body.appendChild(sheet);
    document.getElementById('installIosCloseBtn').addEventListener('click', function () {
      sheet.remove();
    });
  }

  function dismiss() {
    if (banner) banner.remove();
    localStorage.setItem(DISMISS_KEY, '1');
  }

  if (isIos()) {
    banner = buildBanner('ios');
    document.getElementById('installBannerBtn').addEventListener('click', showIosSheet);
    document.getElementById('installBannerClose').addEventListener('click', dismiss);
  } else {
    window.addEventListener('beforeinstallprompt', function (e) {
      e.preventDefault();
      deferredPrompt = e;
      banner = buildBanner('android');
      document.getElementById('installBannerBtn').addEventListener('click', function () {
        if (!deferredPrompt) return;
        deferredPrompt.prompt();
        deferredPrompt.userChoice.finally(function () {
          deferredPrompt = null;
          dismiss();
        });
      });
      document.getElementById('installBannerClose').addEventListener('click', dismiss);
    });
  }
})();
